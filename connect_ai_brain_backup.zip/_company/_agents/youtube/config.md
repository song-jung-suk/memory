# 📺 YouTube 설정 (시크릿)

_이 파일은 `.gitignore`에 의해 깃 동기화에서 제외됩니다. API 키·토큰을 자유롭게 적으세요._

## YouTube Data API
- YOUTUBE_API_KEY: 
- YOUTUBE_CHANNEL_ID: 

