# 🎨 Designer 설정 (시크릿)

_이 파일은 `.gitignore`에 의해 깃 동기화에서 제외됩니다. API 키·토큰을 자유롭게 적으세요._

## 디자인 도구
- FIGMA_TOKEN: 
- STITCH_API_KEY: 

